^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package fiducials
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.12.0 (2021-07-30)
-------------------

0.11.0 (2019-05-09)
-------------------

0.10.0 (2018-10-13)
-------------------

0.9.0 (2018-09-12)
------------------

0.8.4 (2018-08-26)
------------------

0.8.3 (2018-02-26)
------------------

0.8.2 (2018-02-14)
------------------

0.8.1 (2018-01-21)
------------------

0.8.0 (2018-01-14)
------------------
* Remove old style fiducial code
* Contributors: Jim Vaughan

0.7.5 (2017-12-06)
------------------

0.7.4 (2017-11-09)
------------------

0.7.3 (2017-07-16)
------------------

0.7.2 (2017-05-24)
------------------

0.7.1 (2017-05-22)
------------------

0.7.0 (2017-05-21)
------------------
* Update package.xml
  Remove fiducial_slam2
* Added fiducial_slam2 - c++ slam node
* Moved all service and message definitions to fiducial_msgs (`#56 <https://github.com/UbiquityRobotics/fiducials/issues/56>`_)
  * Moved msg and srv to fidicial_msg
  * Moved msg and srv to fidicial_msg
  * Fixed import of srv
  * Fixed import of msg
* Added fiducial_slam2 - c++ slam node
* Moved msg and srv to fidicial_msg
* Contributors: Jim Vaughan

0.6.1 (2017-02-06)
------------------

0.6.0 (2017-02-04)
------------------
* Update package.xml
* 0.5.1
* add changelogs
* Contributors: Jim Vaughan, Rohan Agrawal

0.5.1 (2016-12-28)
------------------